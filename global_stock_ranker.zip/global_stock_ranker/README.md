# Global Stock Ranker

Eine Streamlit-App, die ein weltweites Aktienuniversum mit einem transparenten 0–100-Punkte-Modell priorisiert.

## Was die App macht

- Lädt globale TTM-Kennzahlen in Bulk von Financial Modeling Prep (FMP).
- Ergänzt jährliches Umsatz-, EPS- und Free-Cashflow-Wachstum aus Bulk-Growth-Endpunkten.
- Bewertet jede Aktie in 8 Bereichen:
  - Unternehmensqualität (20)
  - Wachstum (15)
  - Free Cashflow (15)
  - Bilanz (10)
  - Management & Kapitalallokation (10)
  - Moat-Proxy (10)
  - Bewertung (15)
  - Risiko (5)
- Zeigt die Top 100, Detail-Scores und Red-Flag-Abzüge.
- Exportiert die Top 100 als CSV.
- Läuft auch ohne API-Key in einem klar gekennzeichneten synthetischen Demo-Modus.

## Voraussetzungen

Python 3.11+ empfohlen.

```bash
python -m venv .venv
source .venv/bin/activate       # macOS/Linux
# .venv\\Scripts\\activate      # Windows
pip install -r requirements.txt
```

## API-Key

Für echte globale Daten wird ein FMP-API-Key benötigt. Je nach FMP-Tarif sind Bulk-Endpunkte möglicherweise eingeschränkt.

Entweder `.env.example` nach `.env` kopieren:

```bash
cp .env.example .env
```

und dort den Key eintragen, oder den Key direkt in der Seitenleiste der App eingeben.

## Start

```bash
streamlit run app.py
```

Danach im Browser `http://localhost:8501` öffnen.

## Datenquellen / Endpunkte

Die App nutzt die FMP Stable API, insbesondere:

- `/stable/key-metrics-ttm-bulk`
- `/stable/ratios-ttm-bulk`
- `/stable/income-statement-growth-bulk?year=...&period=FY`
- `/stable/cash-flow-statement-growth-bulk?year=...&period=FY`
- `/stable/stock-list`
- optional pro Aktie: `/stable/profile?symbol=...`
- optional pro Aktie: `/stable/analyst-estimates?symbol=...&period=annual`

## Was der Score nicht automatisch lösen kann

Ein globales Ranking aus Fundamentaldaten kann Managementqualität, echten wirtschaftlichen Burggraben, regulatorische Risiken, Bilanzierungsqualität, Kundenkonzentration oder einen vollständigen Reverse DCF nicht zuverlässig automatisieren. Die Kategorien `Kapitalallokation` und `Moat-Proxy` nutzen daher messbare Proxies.

Für eine produktive Investment-App wäre der nächste sinnvolle Schritt:

1. Branchen-spezifische Modelle (insbesondere Banken/Versicherer separat).
2. 5–10 Jahre Historie statt nur TTM + Growth-Bulk.
3. Reverse DCF pro Top-100-Aktie.
4. Analystenrevisionen und Forward-Kennzahlen.
5. Qualitative Unternehmensanalyse aus Geschäftsberichten/Filings.
6. Watchlists, Alerts und tägliche/wochentliche Snapshots.

## Hinweis

Das Tool ist ein Research-/Screening-Werkzeug und keine Anlageberatung oder automatische Kauf-/Verkaufsempfehlung.
