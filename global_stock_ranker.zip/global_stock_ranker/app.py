from __future__ import annotations

import os
from pathlib import Path

import pandas as pd
import streamlit as st
from dotenv import load_dotenv

from src.demo import make_demo_universe
from src.fmp import FMPClient, FMPError, build_global_snapshot
from src.scoring import add_scores, category_from_score


load_dotenv()
CACHE_DIR = Path(".cache")
CACHE_DIR.mkdir(exist_ok=True)
SNAPSHOT = CACHE_DIR / "global_snapshot.csv.gz"

st.set_page_config(page_title="Global Stock Ranker", page_icon="📈", layout="wide")


def pct(v):
    return "—" if pd.isna(v) else f"{v:.1%}"


def multiple(v):
    return "—" if pd.isna(v) else f"{v:.1f}x"


def money(v):
    if pd.isna(v):
        return "—"
    v = float(v)
    if abs(v) >= 1e12:
        return f"{v/1e12:.2f} T"
    if abs(v) >= 1e9:
        return f"{v/1e9:.1f} Mrd."
    if abs(v) >= 1e6:
        return f"{v/1e6:.1f} Mio."
    return f"{v:,.0f}"


def save_snapshot(df: pd.DataFrame):
    df.to_csv(SNAPSHOT, index=False, compression="gzip")


def load_snapshot() -> pd.DataFrame | None:
    if SNAPSHOT.exists():
        return pd.read_csv(SNAPSHOT)
    return None


st.title("Global Stock Ranker")
st.caption(
    "Quantitatives Top-100-Screening nach Qualität, Wachstum, Free Cashflow, Bilanz, "
    "Kapitalallokation, Moat-Proxies, Bewertung und Risiko. Kein Kauf-/Verkaufssignal."
)

with st.sidebar:
    st.header("Daten & Filter")
    env_key = os.getenv("FMP_API_KEY", "")
    api_key = st.text_input("FMP API-Key", value=env_key, type="password", help="Wird nur für die laufende Sitzung verwendet.")
    mode = st.radio("Datenmodus", ["Live / Cache", "Demo"], horizontal=False)
    min_mcap_bn = st.number_input("Min. Marktkapitalisierung (Mrd.)", min_value=0.0, value=1.0, step=0.5)
    min_completeness = st.slider("Min. Datenvollständigkeit", 0, 100, 60, 5)
    exclude_financial_like = st.checkbox(
        "Finanzwerte mit ungeeigneten Kennzahlen herausfiltern",
        value=True,
        help="Ohne Branchenprofil nutzt die App heuristische Plausibilitätsfilter; Banken/Versicherer sollten separat bewertet werden.",
    )
    force_refresh = st.button("Live-Daten neu laden", use_container_width=True)


@st.cache_data(show_spinner=False)
def demo_data() -> pd.DataFrame:
    return make_demo_universe()


def get_live_data() -> pd.DataFrame:
    if not force_refresh:
        cached = load_snapshot()
        if cached is not None and not cached.empty:
            return cached
    if not api_key:
        cached = load_snapshot()
        if cached is not None and not cached.empty:
            return cached
        raise FMPError("Für den ersten Live-Abruf wird ein FMP API-Key benötigt.")
    client = FMPClient(api_key)
    with st.spinner("Globale Bulk-Fundamentaldaten werden geladen …"):
        df = build_global_snapshot(client)
    save_snapshot(df)
    return df


try:
    raw = demo_data() if mode == "Demo" else get_live_data()
except Exception as exc:
    st.error(str(exc))
    st.info("Du kannst auf 'Demo' wechseln, um Oberfläche und Scoring ohne API-Key zu testen.")
    st.stop()

scored = add_scores(raw)
scored["category"] = [category_from_score(s, c) for s, c in zip(scored["score_total"], scored["data_completeness"])]

# Basic investability/data hygiene filters.
if "marketCap" in scored.columns:
    scored["marketCap"] = pd.to_numeric(scored["marketCap"], errors="coerce")
    scored = scored[scored["marketCap"].fillna(0) >= min_mcap_bn * 1e9]
scored = scored[scored["data_completeness"] >= min_completeness]

if exclude_financial_like:
    # Heuristic only: extreme asset/leverage profiles and impossible margin combinations often indicate financials or malformed data.
    if "financialLeverageRatioTTM" in scored.columns:
        lev = pd.to_numeric(scored["financialLeverageRatioTTM"], errors="coerce")
        scored = scored[(lev.isna()) | (lev < 10)]
    if "grossProfitMarginTTM" in scored.columns:
        gm = pd.to_numeric(scored["grossProfitMarginTTM"], errors="coerce")
        scored = scored[(gm.isna()) | ((gm >= 0) & (gm <= 1.2))]

scored = scored.sort_values(["score_total", "data_completeness"], ascending=False).reset_index(drop=True)
scored["rank"] = scored.index + 1

top100 = scored.head(100).copy()

c1, c2, c3, c4 = st.columns(4)
c1.metric("Aktien nach Filter", f"{len(scored):,}".replace(",", "."))
c2.metric("Top-100 Cutoff", f"{top100['score_total'].min():.1f}" if not top100.empty else "—")
roic_series = pd.to_numeric(top100.get("returnOnInvestedCapitalTTM", pd.Series(index=top100.index, dtype=float)), errors="coerce")
fcfy_series = pd.to_numeric(top100.get("freeCashFlowYieldTTM", pd.Series(index=top100.index, dtype=float)), errors="coerce")
c3.metric("Median ROIC Top 100", pct(roic_series.median()) if not top100.empty else "—")
c4.metric("Median FCF Yield Top 100", pct(fcfy_series.median()) if not top100.empty else "—")

rank_tab, detail_tab, methodology_tab = st.tabs(["Top 100", "Detailanalyse", "Methodik"])

with rank_tab:
    st.subheader("Weltweite Top 100 nach Quant-Score")
    if mode == "Demo":
        st.warning("Demo-Modus: Alle Unternehmen und Kennzahlen sind synthetisch und keine realen Aktien.")

    display = pd.DataFrame({
        "Rang": top100["rank"],
        "Ticker": top100["symbol"],
        "Unternehmen": top100.get("name", top100["symbol"]),
        "Score": top100["score_total"].round(1),
        "Daten %": top100["data_completeness"].round(0),
        "Kategorie": top100["category"],
        "Marktkap.": top100.get("marketCap", pd.Series(index=top100.index)).map(money),
        "ROIC": top100.get("returnOnInvestedCapitalTTM", pd.Series(index=top100.index)).map(pct),
        "Umsatzwachstum": top100.get("revenueGrowth", pd.Series(index=top100.index)).map(pct),
        "EPS-Wachstum": top100.get("epsGrowth", pd.Series(index=top100.index)).map(pct),
        "FCF-Wachstum": top100.get("fcfGrowth", pd.Series(index=top100.index)).map(pct),
        "FCF Yield": top100.get("freeCashFlowYieldTTM", pd.Series(index=top100.index)).map(pct),
        "Op. Marge": top100.get("operatingProfitMarginTTM", pd.Series(index=top100.index)).map(pct),
        "Net Debt/EBITDA": top100.get("netDebtToEBITDATTM", pd.Series(index=top100.index)).map(multiple),
        "KGV": top100.get("priceToEarningsRatioTTM", pd.Series(index=top100.index)).map(multiple),
        "EV/EBITDA": top100.get("enterpriseValueMultipleTTM", pd.Series(index=top100.index)).map(multiple),
        "Verwässerung": top100.get("sharesGrowth", pd.Series(index=top100.index)).map(pct),
    })
    st.dataframe(display, hide_index=True, use_container_width=True, height=620)
    st.download_button(
        "Top 100 als CSV herunterladen",
        data=top100.to_csv(index=False).encode("utf-8"),
        file_name="global_stock_top100.csv",
        mime="text/csv",
    )

with detail_tab:
    if top100.empty:
        st.info("Keine Aktien erfüllen die aktuellen Filter.")
    else:
        labels = {f"#{int(r['rank'])} · {r['symbol']} · {r.get('name', r['symbol'])}": i for i, r in top100.iterrows()}
        label = st.selectbox("Aktie auswählen", list(labels.keys()))
        row = top100.loc[labels[label]]
        st.subheader(f"{row.get('name', row['symbol'])} ({row['symbol']})")
        st.write(f"**Gesamtscore:** {row['score_total']:.1f}/100 · **Datenvollständigkeit:** {row['data_completeness']:.0f}% · **Kategorie:** {row['category']}")

        score_table = pd.DataFrame({
            "Bereich": ["Unternehmensqualität", "Wachstum", "Free Cashflow", "Bilanz", "Management & Kapitalallokation", "Moat-Proxy", "Bewertung", "Risiko"],
            "Punkte": [row["score_quality"], row["score_growth"], row["score_cashflow"], row["score_balance"], row["score_capital_allocation"], row["score_moat"], row["score_valuation"], row["score_risk"]],
            "Maximum": [20, 15, 15, 10, 10, 10, 15, 5],
        })
        score_table["Erfüllung %"] = score_table["Punkte"] / score_table["Maximum"] * 100
        st.bar_chart(score_table.set_index("Bereich")["Erfüllung %"], horizontal=True)

        a, b, c, d = st.columns(4)
        a.metric("ROIC", pct(row.get("returnOnInvestedCapitalTTM")))
        b.metric("FCF Yield", pct(row.get("freeCashFlowYieldTTM")))
        c.metric("Umsatzwachstum", pct(row.get("revenueGrowth")))
        d.metric("EPS-Wachstum", pct(row.get("epsGrowth")))
        e, f, g, h = st.columns(4)
        e.metric("FCF-Marge", pct(row.get("fcfMarginTTM")))
        f.metric("Net Debt / EBITDA", multiple(row.get("netDebtToEBITDATTM")))
        g.metric("KGV", multiple(row.get("priceToEarningsRatioTTM")))
        h.metric("Aktienzahl-Wachstum", pct(row.get("sharesGrowth")))

        if row.get("red_flag_penalty", 0) > 0:
            st.warning(f"Red-Flag-Abzug: {row['red_flag_penalty']:.1f} Punkte. Die Aktie sollte vor jeder Entscheidung qualitativ geprüft werden.")

        if mode != "Demo" and api_key:
            if st.button("Profil + Analystenschätzungen nachladen"):
                client = FMPClient(api_key)
                try:
                    profile = client.profile(str(row["symbol"]))
                    estimates = client.analyst_estimates(str(row["symbol"]))
                    if not profile.empty:
                        st.markdown("#### Unternehmensprofil")
                        cols = [c for c in ["companyName", "sector", "industry", "country", "exchange", "price", "marketCap", "description"] if c in profile.columns]
                        st.dataframe(profile[cols], hide_index=True, use_container_width=True)
                    if not estimates.empty:
                        st.markdown("#### Analystenschätzungen")
                        cols = [c for c in ["date", "revenueAvg", "epsAvg", "numAnalystsRevenue", "numAnalystsEps"] if c in estimates.columns]
                        st.dataframe(estimates[cols].sort_values("date"), hide_index=True, use_container_width=True)
                except Exception as exc:
                    st.error(str(exc))

with methodology_tab:
    st.subheader("Scoring-Modell")
    st.markdown(
        """
Die App setzt dein 100-Punkte-Modell quantitativ um:

- **Unternehmensqualität (20):** ROIC, operative Marge, Bruttomarge, Gewinn-/Cashflow-Qualität.
- **Wachstum (15):** durchschnittliches Umsatz-, EPS- und FCF-Wachstum aus den letzten verfügbaren Geschäftsjahren.
- **Free Cashflow (15):** FCF-Marge, Cash Conversion und FCF Yield.
- **Bilanz (10):** Net Debt/EBITDA, Current Ratio und Zinsdeckung.
- **Management & Kapitalallokation (10):** Verwässerung/Aktienrückkäufe, Stock-Based Compensation und Kapitalintensität als messbare Proxies.
- **Moat-Proxy (10):** ROIC sowie Brutto- und operative Marge. Das ist ein Indiz, kein Beweis für einen Burggraben.
- **Bewertung (15):** FCF Yield, KGV, EV/EBITDA und PEG.
- **Risiko (5):** Bilanz- und Margenresilienz; zusätzlich gibt es explizite Red-Flag-Abzüge.

**Wichtig:** Dinge wie Markenstärke, Wechselkosten, Managementintegrität, Kundenkonzentration, regulatorische Risiken und ein echter Reverse DCF lassen sich nicht zuverlässig aus einer einzigen Bulk-Datentabelle ableiten. Die App nutzt deshalb das Ranking als **Priorisierung für die tiefere Analyse**, nicht als automatische Kaufentscheidung.
        """
    )
    st.markdown("#### Harte Red-Flag-Abzüge")
    st.write("Negativer FCF, negativer ROIC, sehr hohe Verschuldung, negative operative Marge, starke Verwässerung, extrem hohe SBC sowie sehr hohe Bewertung bei schwachem Wachstum reduzieren den Score.")
