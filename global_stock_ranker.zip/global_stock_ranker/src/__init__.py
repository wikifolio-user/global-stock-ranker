"""Global Stock Ranker package."""
