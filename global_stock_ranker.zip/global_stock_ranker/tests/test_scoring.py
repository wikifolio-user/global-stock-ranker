import pandas as pd

from src.demo import make_demo_universe
from src.scoring import add_scores


def test_score_bounds_and_shape():
    df = make_demo_universe(50)
    out = add_scores(df)
    assert len(out) == 50
    assert out["score_total"].between(0, 100).all()
    assert out["data_completeness"].between(0, 100).all()


def test_good_company_scores_better_than_bad_company():
    base = {
        "symbol": ["GOOD", "BAD"],
        "returnOnInvestedCapitalTTM": [0.30, -0.05],
        "grossProfitMarginTTM": [0.65, 0.15],
        "operatingProfitMarginTTM": [0.30, -0.03],
        "incomeQualityTTM": [1.2, 0.3],
        "freeCashFlowOperatingCashFlowRatioTTM": [0.95, 0.2],
        "freeCashFlowYieldTTM": [0.07, -0.01],
        "netDebtToEBITDATTM": [0.5, 5.0],
        "currentRatioTTM": [1.8, 0.6],
        "interestCoverageRatioTTM": [12, 0.5],
        "priceToEarningsRatioTTM": [20, 80],
        "forwardPriceToEarningsGrowthRatioTTM": [1.2, 4],
        "enterpriseValueMultipleTTM": [12, 35],
        "stockBasedCompensationToRevenueTTM": [0.02, 0.18],
        "capexToRevenueTTM": [0.05, 0.25],
        "revenuePerShareTTM": [100, 100],
        "freeCashFlowPerShareTTM": [20, -5],
        "revenueGrowth": [0.12, -0.10],
        "epsGrowth": [0.15, -0.20],
        "fcfGrowth": [0.14, -0.30],
        "sharesGrowth": [-0.01, 0.12],
    }
    out = add_scores(pd.DataFrame(base)).set_index("symbol")
    assert out.loc["GOOD", "score_total"] > out.loc["BAD", "score_total"]
